<nav class="navbar background h-nav-resp">
    <ul class="nav-list v-class-resp">
        <div class="logo">
            <img src="img/logo.jpg" alt="Logo not found">
        </div>
        <li><a href="index.php">Home</a></li>
        <li><a href="customers.php">Customers</a></li>
        <li><a href="transactionHistory.php">Transaction History</a></li>
    </ul>
    <div class="rightNav v-class-resp">
        
    </div>
    <div class="burger">
        <div class="line"></div>
        <div class="line"></div>
        <div class="line"></div>
    </div>
</nav>