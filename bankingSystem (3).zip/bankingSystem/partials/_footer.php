
<footer>
    <p class="text-footer">
        Copyright &copy; 2021 | All rights reserved | Spark Foundation | Created By: Aman Sahani
    </p>
</footer>