<?php
    $conn = mysqli_connect("localhost","root","","bankingsystem");
    if(!$conn){
        echo "Database Connected" . mysqli_connect_error();
    }
?>